import discord
from discord.ext import commands
from discord.ui import View, Button
import yt_dlp as youtube_dl
import asyncio
import os
import random as rand
import time
from collections import OrderedDict
from dotenv import load_dotenv

load_dotenv()

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }],
    'noplaylist': True,
    'quiet': True,
    'no_warnings': True,
    'socket_timeout': 10,
    'retries': 2,
}

RANDOM_QUERIES = [
    "phonk", "drift phonk", "slowed phonk", "brazilian phonk", "aggresive phonk",
    "funk brasil", "phonk remix", "phonk 2024", "drift music",
    "russian hits 2024", "russian rap", "russian pop", "русская музыка",
    "russian rock", "russian indie", "russian phonk", "kyivstoner",
    "korzh", "skriptonit", "morgenshtern", "big baby tape", "oxxxymiron",
    "face", "thomas mraz", "jedi mind tricks", "kizaru", "saluki",
    "aphrodite", "xcho", "andy panda", "miyagi", "timati", "egor krid",
    "slava marlow", "boulevard depo", "pharaoh", "lsp", "markul",
    "t-fest", "skryptonite", "niman", "zomb", "dequine",
    "sigma music", "gigachad music", "sad music", "night drive music",
    "gaming music 2024", "csgo music", "dota 2 music", "minecraft music",
    "lofi hip hop", "popular music 2024", "rock classics", "electronic dance music",
    "jazz relax", "indie pop", "classical music", "rap hits", "synthwave",
    "metal hits", "pop hits 2024", "nightcore", "acoustic covers",
    "the weeknd", "imagine dragons", "linkin park", "queen", "arctic monkeys",
    "radiohead", "nirvana", "metallica", "eminem", "kanye west", "drake",
    "dua lipa", "billie eilish", "post malone", "travis scott", "xxx tentacion"
]


class QueueView(View):
    """Кнопки управления в меню очереди"""
    def __init__(self, bot_instance, ctx):
        super().__init__(timeout=60)
        self.bot = bot_instance
        self.ctx = ctx
        
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not self.ctx.voice_client:
            await interaction.response.send_message("❌ Бот не в голосовом канале", ephemeral=True)
            return False
        if not interaction.user.voice or interaction.user.voice.channel != self.ctx.voice_client.channel:
            await interaction.response.send_message("❌ Ты не в голосовом канале с ботом", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="⏮️", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, interaction: discord.Interaction, button: Button):
        await self.do_previous(interaction)
        
    @discord.ui.button(label="⏸️", style=discord.ButtonStyle.primary)
    async def pause_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and self.ctx.voice_client.is_playing():
            self.ctx.voice_client.pause()
            await interaction.response.send_message("⏸️ Пауза", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    @discord.ui.button(label="▶️", style=discord.ButtonStyle.success)
    async def resume_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and self.ctx.voice_client.is_paused():
            self.ctx.voice_client.resume()
            await interaction.response.send_message("▶️ Продолжаю", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Нет паузы", ephemeral=True)

    @discord.ui.button(label="⏭️", style=discord.ButtonStyle.danger)
    async def skip_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and (self.ctx.voice_client.is_playing() or self.ctx.voice_client.is_paused()):
            self.ctx.voice_client.stop()
            await interaction.response.send_message("⏭️ Пропущено", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    @discord.ui.button(label="🗑️", style=discord.ButtonStyle.red)
    async def delete_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and (self.ctx.voice_client.is_playing() or self.ctx.voice_client.is_paused()):
            self.ctx.voice_client.stop()
            await interaction.response.send_message("🗑️ Трек удален", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    @discord.ui.button(label="🎲", style=discord.ButtonStyle.blurple, row=1)
    async def add_random(self, interaction: discord.Interaction, button: Button):
        """Добавить случайное количество треков (3-8)"""
        count = rand.randint(3, 8)  # Случайное количество
        await interaction.response.send_message("🎲 Ищу случайные треки...", ephemeral=True)
        added = await self.bot.add_random_tracks(self.ctx, count=count)
        await interaction.followup.send(f"✅ Добавлено {added} треков!", ephemeral=True)
        await self.update_queue_message(interaction)

    @discord.ui.button(label="🔀", style=discord.ButtonStyle.secondary, row=1)
    async def shuffle_btn(self, interaction: discord.Interaction, button: Button):
        queue = self.bot.get_queue(self.ctx.guild.id)
        if len(queue) < 2:
            await interaction.response.send_message("❌ Недостаточно треков", ephemeral=True)
            return
        rand.shuffle(queue)
        await interaction.response.send_message(f"🔀 Очередь перемешана!", ephemeral=True)
        await self.update_queue_message(interaction)

    @discord.ui.button(label="🔁", style=discord.ButtonStyle.secondary, row=1)
    async def loop_btn(self, interaction: discord.Interaction, button: Button):
        current_mode = self.bot.loop_modes.get(self.ctx.guild.id, 'off')
        modes = {'off': 'one', 'one': 'all', 'all': 'off'}
        new_mode = modes[current_mode]
        self.bot.loop_modes[self.ctx.guild.id] = new_mode
        emojis = {'off': '❌', 'one': '🔂', 'all': '🔁'}
        await interaction.response.send_message(f"{emojis[new_mode]} Режим повтора: {new_mode}", ephemeral=True)

    @discord.ui.button(label="🚪", style=discord.ButtonStyle.red, row=1)
    async def leave_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client:
            self.bot.queues[self.ctx.guild.id] = []
            self.bot.current[self.ctx.guild.id] = None
            self.bot.history[self.ctx.guild.id] = []
            self.ctx.voice_client.stop()
            await self.ctx.voice_client.disconnect()
            await interaction.response.send_message("🚪 Бот отключен", ephemeral=True)
            self.stop()
        else:
            await interaction.response.send_message("❌ Я не в канале", ephemeral=True)

    async def do_previous(self, interaction):
        history = self.bot.history.get(self.ctx.guild.id, [])
        if not history:
            await interaction.response.send_message("❌ Нет предыдущих треков", ephemeral=True)
            return
        
        prev_song = history.pop()
        queue = self.bot.get_queue(self.ctx.guild.id)
        
        current = self.bot.current.get(self.ctx.guild.id)
        if current and self.ctx.voice_client.is_playing():
            queue.insert(0, current)
        
        queue.insert(0, prev_song)
        self.ctx.voice_client.stop()
        await interaction.response.send_message("⏮️ Возвращаю предыдущий трек", ephemeral=True)

    async def update_queue_message(self, interaction):
        queue_list = self.bot.get_queue(self.ctx.guild.id)
        current = self.bot.current.get(self.ctx.guild.id)
        
        embed = discord.Embed(title="📜 Текущая очередь", color=discord.Color.purple())
        
        if current:
            start_time = self.bot.start_times.get(self.ctx.guild.id, time.time())
            elapsed = int(time.time() - start_time)
            total = current.get('duration_seconds', 0)
            progress_bar = self.bot.create_progress_bar(elapsed, total)
            time_str = self.bot.format_duration(elapsed)
            total_str = current['duration']
            
            embed.add_field(
                name="▶️ Сейчас",
                value=f"[{current['title'][:40]}...]({current['webpage_url']})\n"
                      f"`{progress_bar}`\n`{time_str} / {total_str}`",
                inline=False
            )
        
        if queue_list:
            text = ""
            for i, song in enumerate(queue_list[:8], 1):
                text += f"`{i}.` {song['title'][:30]}... | `{song['duration']}`\n"
            if len(queue_list) > 8:
                text += f"\n*...и еще {len(queue_list)-8}*"
            embed.add_field(name=f"Далее ({len(queue_list)}):", value=text, inline=False)
        
        history_count = len(self.bot.history.get(self.ctx.guild.id, []))
        embed.set_footer(text=f"⏮️ История: {history_count} треков")
        
        await interaction.message.edit(embed=embed, view=self)


class MusicControls(View):
    """Основные кнопки под треком"""
    def __init__(self, bot_instance, ctx):
        super().__init__(timeout=None)
        self.bot = bot_instance
        self.ctx = ctx
        
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not self.ctx.voice_client:
            await interaction.response.send_message("❌ Бот не в голосовом канале", ephemeral=True)
            return False
        if not interaction.user.voice or interaction.user.voice.channel != self.ctx.voice_client.channel:
            await interaction.response.send_message("❌ Ты не в голосовом канале с ботом", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="⏮️", style=discord.ButtonStyle.secondary, custom_id="prev_main")
    async def prev_btn(self, interaction: discord.Interaction, button: Button):
        await self.do_previous(interaction)

    @discord.ui.button(label="⏸️", style=discord.ButtonStyle.primary, custom_id="pause_main")
    async def pause_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and self.ctx.voice_client.is_playing():
            self.ctx.voice_client.pause()
            await interaction.response.edit_message(content="⏸️ Пауза")
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    @discord.ui.button(label="▶️", style=discord.ButtonStyle.success, custom_id="resume_main")
    async def resume_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and self.ctx.voice_client.is_paused():
            self.ctx.voice_client.resume()
            await interaction.response.edit_message(content="▶️ Продолжаю")
        else:
            await interaction.response.send_message("❌ Нет паузы", ephemeral=True)

    @discord.ui.button(label="⏭️", style=discord.ButtonStyle.danger, custom_id="skip_main")
    async def skip_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and (self.ctx.voice_client.is_playing() or self.ctx.voice_client.is_paused()):
            self.ctx.voice_client.stop()
            await interaction.response.send_message("⏭️ Пропущено", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    @discord.ui.button(label="🗑️", style=discord.ButtonStyle.red, custom_id="delete_main")
    async def delete_btn(self, interaction: discord.Interaction, button: Button):
        if self.ctx.voice_client and (self.ctx.voice_client.is_playing() or self.ctx.voice_client.is_paused()):
            self.ctx.voice_client.stop()
            await interaction.response.send_message("🗑️ Трек удален", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Ничего не играет", ephemeral=True)

    @discord.ui.button(label="📜", style=discord.ButtonStyle.secondary, row=1, custom_id="queue_main")
    async def queue_btn(self, interaction: discord.Interaction, button: Button):
        queue_list = self.bot.get_queue(self.ctx.guild.id)
        current = self.bot.current.get(self.ctx.guild.id)
        
        if not current and not queue_list:
            await interaction.response.send_message("📭 Очередь пуста", ephemeral=True)
            return
        
        embed = discord.Embed(title="📜 Текущая очередь", color=discord.Color.purple())
        
        if current:
            start_time = self.bot.start_times.get(self.ctx.guild.id, time.time())
            elapsed = int(time.time() - start_time)
            total = current.get('duration_seconds', 0)
            progress_bar = self.bot.create_progress_bar(elapsed, total)
            time_str = self.bot.format_duration(elapsed)
            total_str = current['duration']
            
            embed.add_field(
                name="▶️ Сейчас",
                value=f"[{current['title'][:40]}...]({current['webpage_url']})\n"
                      f"`{progress_bar}`\n`{time_str} / {total_str}`",
                inline=False
            )
        
        if queue_list:
            text = ""
            for i, song in enumerate(queue_list[:8], 1):
                text += f"`{i}.` {song['title'][:30]}... | `{song['duration']}`\n"
            if len(queue_list) > 8:
                text += f"\n*...и еще {len(queue_list)-8}*"
            embed.add_field(name=f"Далее ({len(queue_list)}):", value=text, inline=False)
        
        history_count = len(self.bot.history.get(self.ctx.guild.id, []))
        embed.set_footer(text=f"⏮️ История: {history_count} треков | Управляй кнопками ниже")
        
        view = QueueView(self.bot, self.ctx)
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

    @discord.ui.button(label="🔁", style=discord.ButtonStyle.secondary, row=1, custom_id="loop_main")
    async def loop_btn(self, interaction: discord.Interaction, button: Button):
        current_mode = self.bot.loop_modes.get(self.ctx.guild.id, 'off')
        modes = {'off': 'one', 'one': 'all', 'all': 'off'}
        new_mode = modes[current_mode]
        self.bot.loop_modes[self.ctx.guild.id] = new_mode
        emojis = {'off': '❌', 'one': '🔂', 'all': '🔁'}
        await interaction.response.send_message(f"{emojis[new_mode]} Режим повтора: {new_mode}", ephemeral=True)

    @discord.ui.button(label="🔀", style=discord.ButtonStyle.secondary, row=1, custom_id="shuffle_main")
    async def shuffle_btn(self, interaction: discord.Interaction, button: Button):
        queue = self.bot.get_queue(self.ctx.guild.id)
        if len(queue) < 2:
            await interaction.response.send_message("❌ Недостаточно треков", ephemeral=True)
            return
        rand.shuffle(queue)
        await interaction.response.send_message(f"🔀 Очередь перемешана! ({len(queue)} треков)", ephemeral=True)

    @discord.ui.button(label="🎲", style=discord.ButtonStyle.blurple, row=1, custom_id="add_random")
    async def add_random_btn(self, interaction: discord.Interaction, button: Button):
        """Добавить случайное количество треков (3-8)"""
        count = rand.randint(3, 8)
        await interaction.response.send_message("🎲 Ищу случайные треки...", ephemeral=True)
        added = await self.bot.add_random_tracks(self.ctx, count=count)
        await interaction.followup.send(f"✅ Добавлено {added} треков в очередь!", ephemeral=True)

    async def do_previous(self, interaction):
        history = self.bot.history.get(self.ctx.guild.id, [])
        if not history:
            await interaction.response.send_message("❌ Нет предыдущих треков", ephemeral=True)
            return
        
        prev_song = history.pop()
        queue = self.bot.get_queue(self.ctx.guild.id)
        
        current = self.bot.current.get(self.ctx.guild.id)
        if current and self.ctx.voice_client.is_playing():
            queue.insert(0, current)
        
        queue.insert(0, prev_song)
        self.ctx.voice_client.stop()
        await interaction.response.send_message("⏮️ Возвращаю предыдущий трек", ephemeral=True)


class MusicBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.voice_states = True
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None,
            case_insensitive=True
        )
        
        self.queues = {}
        self.current = {}
        self.history = {}
        self.loop_modes = {}
        self.start_times = {}
        self.search_cache = OrderedDict()
        self.MAX_CACHE_SIZE = 50
        self.MAX_DURATION_SECONDS = 420
        
        # Умный рандом - история тегов по серверам
        self.played_tracks = {}  # guild_id -> список последних тегов
        self.MAX_HISTORY_TRACKS = 20  # Не повторять последние 20 тегов

    def get_queue(self, guild_id):
        if guild_id not in self.queues:
            self.queues[guild_id] = []
        return self.queues[guild_id]

    def get_history(self, guild_id):
        if guild_id not in self.history:
            self.history[guild_id] = []
        return self.history[guild_id]

    def get_cached_search(self, query, max_results):
        cache_key = f"{query}_{max_results}"
        if cache_key in self.search_cache:
            self.search_cache.move_to_end(cache_key)
            return self.search_cache[cache_key]
        return None

    def set_cached_search(self, query, max_results, results):
        cache_key = f"{query}_{max_results}"
        self.search_cache[cache_key] = results
        self.search_cache.move_to_end(cache_key)
        if len(self.search_cache) > self.MAX_CACHE_SIZE:
            self.search_cache.popitem(last=False)

    def get_random_query(self, guild_id):
        """Получить случайный тег, исключая недавно played"""
        if guild_id not in self.played_tracks:
            self.played_tracks[guild_id] = []
        
        # Фильтруем список, убирая недавние
        available = [q for q in RANDOM_QUERIES if q not in self.played_tracks[guild_id]]
        
        # Если все теги в истории - очищаем историю
        if not available:
            self.played_tracks[guild_id] = []
            available = RANDOM_QUERIES
        
        choice = rand.choice(available)
        
        # Добавляем в историю
        self.played_tracks[guild_id].append(choice)
        if len(self.played_tracks[guild_id]) > self.MAX_HISTORY_TRACKS:
            self.played_tracks[guild_id].pop(0)
        
        return choice

    async def search_youtube(self, query, max_results=1):
        cached = self.get_cached_search(query, max_results)
        if cached:
            return cached

        def search():
            with youtube_dl.YoutubeDL(YDL_OPTIONS) as ydl:
                try:
                    if 'youtube.com' in query or 'youtu.be' in query:
                        info = ydl.extract_info(query, download=False)
                        return [info] if max_results == 1 else info
                    else:
                        info = ydl.extract_info(f"ytsearch{max_results}:{query}", download=False)
                        return info['entries']
                except Exception as e:
                    error_msg = str(e)
                    if "age-restricted" in error_msg:
                        return "age_restricted"
                    print(f"Ошибка поиска: {e}")
                    return None
        
        try:
            loop = asyncio.get_event_loop()
            results = await asyncio.wait_for(
                loop.run_in_executor(None, search),
                timeout=15.0
            )
            if results and results != "age_restricted":
                self.set_cached_search(query, max_results, results)
            return results
        except asyncio.TimeoutError:
            return None
        except Exception as e:
            print(f"Ошибка: {e}")
            return None

    async def add_random_tracks(self, ctx, count=5):
        """Добавить count случайных треков с проверкой на дубликаты"""
        added = 0
        attempts = 0
        max_attempts = count * 4
        
        # Храним ID добавленных видео, чтобы не дублировать в одной пачке
        added_video_ids = set()
        
        if not ctx.voice_client:
            await ctx.author.voice.channel.connect()
        elif ctx.voice_client.channel != ctx.author.voice.channel:
            return 0
        
        while added < count and attempts < max_attempts:
            query = self.get_random_query(ctx.guild.id)  # Используем умный выбор
            results = await self.search_youtube(query, max_results=3)
            
            if results and results != "age_restricted" and len(results) > 0:
                for video in results:
                    video_id = video.get('id') or video.get('webpage_url', '')
                    
                    # Проверяем дубликат в текущей пачке
                    if video_id in added_video_ids:
                        continue
                    
                    dur = video.get('duration', 0)
                    if isinstance(dur, int) and 0 < dur <= self.MAX_DURATION_SECONDS:
                        song = {
                            'title': video['title'],
                            'url': video['url'],
                            'webpage_url': video['webpage_url'],
                            'thumbnail': video.get('thumbnail'),
                            'duration': self.format_duration(dur),
                            'duration_seconds': dur,
                            'requester': ctx.author.name
                        }
                        
                        added_video_ids.add(video_id)
                        self.get_queue(ctx.guild.id).append(song)
                        
                        # Если ничего не играет - сразу запускаем
                        if not ctx.voice_client.is_playing() and not self.current.get(ctx.guild.id):
                            await self.play_next(ctx)
                        
                        added += 1
                        break
            
            attempts += 1
            await asyncio.sleep(0.3)  # Небольшая задержка между запросами
        
        return added

    def format_duration(self, seconds):
        if not seconds or seconds <= 0:
            return "N/A"
        mins = seconds // 60
        secs = seconds % 60
        return f"{mins}:{secs:02d}"

    def create_progress_bar(self, current, total, length=15):
        if not total or total <= 0:
            return "▬" * length
        progress = min(current / total, 1.0)
        filled = int(length * progress)
        empty = length - filled
        if empty > 0:
            return "▬" * filled + "🔘" + "▬" * (empty - 1)
        return "▬" * length

    async def play_next(self, ctx):
        queue = self.get_queue(ctx.guild.id)
        history = self.get_history(ctx.guild.id)
        
        if queue:
            song = queue.pop(0)
            current = self.current.get(ctx.guild.id)
            
            if current:
                history.append(current)
                if len(history) > 20:
                    history.pop(0)
            
            if self.loop_modes.get(ctx.guild.id) == 'one':
                queue.insert(0, song.copy())
            elif self.loop_modes.get(ctx.guild.id) == 'all':
                queue.append(song.copy())
            
            self.current[ctx.guild.id] = song
            self.start_times[ctx.guild.id] = time.time()
            
            if not ctx.voice_client:
                return
            
            source = discord.FFmpegPCMAudio(song['url'], **FFMPEG_OPTIONS)
            
            def after_playing(error):
                if error:
                    print(f"Ошибка: {error}")
                asyncio.run_coroutine_threadsafe(self.play_next(ctx), self.loop)
            
            ctx.voice_client.play(source, after=after_playing)
            
            duration = song.get('duration_seconds', 0)
            duration_str = self.format_duration(duration)
            
            embed = discord.Embed(
                title="▶️ Сейчас играет",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.green()
            )
            
            if song.get('thumbnail'):
                embed.set_thumbnail(url=song['thumbnail'])
            
            progress_bar = self.create_progress_bar(0, duration)
            embed.add_field(name="Прогресс", value=f"`{progress_bar}` 0:00 / {duration_str}", inline=False)
            embed.set_footer(text=f"Запросил: {song['requester']} | 🔁 {self.loop_modes.get(ctx.guild.id, 'off')}")
            
            view = MusicControls(self, ctx)
            msg = await ctx.send(embed=embed, view=view)
            
            if duration > 0:
                asyncio.create_task(self.update_progress_bar(ctx, msg, duration))
        else:
            self.current[ctx.guild.id] = None
            self.start_times[ctx.guild.id] = None
            await ctx.send("✅ Очередь закончилась. Отключаюсь через 30 секунд...")
            await asyncio.sleep(30)
            if ctx.voice_client and not self.current.get(ctx.guild.id):
                await ctx.voice_client.disconnect()

    async def update_progress_bar(self, ctx, message, total_duration):
        start_time = self.start_times.get(ctx.guild.id, time.time())
        
        while (ctx.voice_client and 
               (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()) and
               self.current.get(ctx.guild.id)):
            
            current_time = time.time() - start_time
            if current_time > total_duration:
                break
                
            if int(current_time) % 10 == 0:
                try:
                    embed = message.embeds[0]
                    progress_bar = self.create_progress_bar(current_time, total_duration)
                    time_str = self.format_duration(int(current_time))
                    total_str = self.format_duration(total_duration)
                    
                    embed.set_field_at(0, name="Прогресс", 
                                     value=f"`{progress_bar}` {time_str} / {total_str}", 
                                     inline=False)
                    await message.edit(embed=embed)
                except:
                    pass
            
            await asyncio.sleep(1)

    async def add_to_queue(self, ctx, song_info):
        song = {
            'title': song_info['title'],
            'url': song_info['url'],
            'webpage_url': song_info['webpage_url'],
            'thumbnail': song_info.get('thumbnail'),
            'duration': self.format_duration(song_info.get('duration', 0)),
            'duration_seconds': song_info.get('duration', 0) if isinstance(song_info.get('duration'), int) else 0,
            'requester': ctx.author.name
        }
        
        if ctx.voice_client and ctx.voice_client.is_playing():
            self.get_queue(ctx.guild.id).append(song)
            embed = discord.Embed(
                title="📝 Добавлено в очередь",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.blue()
            )
            embed.set_thumbnail(url=song['thumbnail'])
            embed.add_field(name="Длительность", value=song['duration'], inline=True)
            embed.add_field(name="Позиция", value=len(self.get_queue(ctx.guild.id)), inline=True)
            await ctx.send(embed=embed)
        else:
            self.get_queue(ctx.guild.id).append(song)
            await self.play_next(ctx)


bot = MusicBot()

@bot.event
async def on_ready():
    print(f'✅ Бот {bot.user} запущен!')

@bot.event
async def on_voice_state_update(member, before, after):
    if member.bot:
        return
    
    voice_client = discord.utils.get(bot.voice_clients, guild=member.guild)
    
    if before.channel and voice_client and voice_client.channel == before.channel:
        members = [m for m in before.channel.members if not m.bot]
        if len(members) == 0:
            await asyncio.sleep(5)
            members = [m for m in before.channel.members if not m.bot]
            if len(members) == 0 and voice_client.is_connected():
                await voice_client.disconnect()

@bot.command()
async def start(ctx):
    """!start - подключить бота и показать панель управления"""
    if not ctx.author.voice:
        return await ctx.send("❌ Сначала зайди в голосовой канал!")
    
    # Подключаемся если еще не подключены
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
        await ctx.send(f"✅ Подключился к **{ctx.author.voice.channel.name}**")
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send(f"❌ Бот занят в другом канале: **{ctx.voice_client.channel.name}**")
    
    current = bot.current.get(ctx.guild.id)
    queue_list = bot.get_queue(ctx.guild.id)
    
    if current:
        # Если что-то играет - показываем текущий плеер
        duration = current.get('duration_seconds', 0)
        duration_str = bot.format_duration(duration)
        
        embed = discord.Embed(
            title="🎵 Панель управления",
            description=f"[{current['title']}]({current['webpage_url']})",
            color=discord.Color.green()
        )
        
        if current.get('thumbnail'):
            embed.set_thumbnail(url=current['thumbnail'])
        
        start_time = bot.start_times.get(ctx.guild.id, time.time())
        elapsed = int(time.time() - start_time)
        progress_bar = bot.create_progress_bar(elapsed, duration)
        time_str = bot.format_duration(elapsed)
        
        embed.add_field(name="Прогресс", value=f"`{progress_bar}` {time_str} / {duration_str}", inline=False)
        embed.add_field(name="В очереди", value=f"{len(queue_list)} треков", inline=True)
        embed.add_field(name="Режим", value=f"🔁 {bot.loop_modes.get(ctx.guild.id, 'off')}", inline=True)
        embed.set_footer(text=f"Запросил: {current['requester']}")
        
        view = MusicControls(bot, ctx)
        await ctx.send(embed=embed, view=view)
    else:
        # Пустая панель с кнопками
        embed = discord.Embed(
            title="🎵 Панель управления",
            description="Готов играть! Используй кнопки ниже:",
            color=discord.Color.blue()
        )
        embed.add_field(name="В очереди", value=f"{len(queue_list)} треков", inline=True)
        embed.add_field(name="Режим", value=f"🔁 {bot.loop_modes.get(ctx.guild.id, 'off')}", inline=True)
        embed.set_footer(text="🎲 — добавить несколько случайных треков")
        
        view = MusicControls(bot, ctx)
        await ctx.send(embed=embed, view=view)

@bot.command()
async def play(ctx, *, query):
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send("❌ Бот занят в другом канале!")
    
    async with ctx.typing():
        results = await bot.search_youtube(query, max_results=1)
    
    if results == "age_restricted":
        return await ctx.send("🔞 Видео имеет возрастное ограничение.")
    
    if not results or len(results) == 0:
        return await ctx.send("❌ Не удалось найти видео!")
    
    song_info = results[0] if isinstance(results, list) else results
    await bot.add_to_queue(ctx, song_info)

@bot.command()
async def previous(ctx):
    if not ctx.voice_client:
        return await ctx.send("❌ Ничего не играет")
    
    history = bot.get_history(ctx.guild.id)
    if not history:
        return await ctx.send("❌ Нет предыдущих треков")
    
    prev_song = history.pop()
    queue = bot.get_queue(ctx.guild.id)
    
    current = bot.current.get(ctx.guild.id)
    if current and ctx.voice_client.is_playing():
        queue.insert(0, current)
    
    queue.insert(0, prev_song)
    ctx.voice_client.stop()
    await ctx.send(f"⏮️ Возвращаю: {prev_song['title'][:40]}...")

@bot.command()
async def search(ctx, *, query):
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    async with ctx.typing():
        results = await bot.search_youtube(query, max_results=5)
    
    if results == "age_restricted":
        return await ctx.send("🔞 Найдены только видео с ограничениями.")
    
    if not results or len(results) == 0:
        return await ctx.send("❌ Ничего не найдено!")
    
    embed = discord.Embed(
        title=f"🔍 Результаты: {query}",
        description="Напиши номер (1-5) или `отмена`",
        color=discord.Color.gold()
    )
    
    for i, video in enumerate(results[:5], 1):
        duration = bot.format_duration(video.get('duration', 0))
        embed.add_field(
            name=f"{i}. {video['title'][:45]}",
            value=f"Длительность: {duration}",
            inline=False
        )
    
    await ctx.send(embed=embed)
    
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and \
               (m.content.isdigit() and 1 <= int(m.content) <= 5 or m.content.lower() in ['отмена', 'cancel'])
    
    try:
        response = await bot.wait_for('message', check=check, timeout=30.0)
        
        if response.content.lower() in ['отмена', 'cancel']:
            return await ctx.send("❌ Отменено")
        
        choice = int(response.content) - 1
        selected = results[choice]
        
        if not ctx.voice_client:
            await ctx.author.voice.channel.connect()
        elif ctx.voice_client.channel != ctx.author.voice.channel:
            return await ctx.send("❌ Бот занят в другом канале!")
        
        await bot.add_to_queue(ctx, selected)
        
    except asyncio.TimeoutError:
        await ctx.send("⏰ Время вышло!")

@bot.command()
async def random(ctx):
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    query = bot.get_random_query(ctx.guild.id)  # Используем умный рандом
    
    async with ctx.typing():
        results = await bot.search_youtube(query, max_results=5)
    
    if results == "age_restricted":
        return await ctx.send("🔞 Не удалось найти подходящий трек.")
    
    if not results:
        return await ctx.send("❌ Не удалось найти музыку!")
    
    song_info = None
    for video in results:
        dur = video.get('duration', 0)
        if isinstance(dur, int) and 0 < dur <= bot.MAX_DURATION_SECONDS:
            song_info = video
            break
    
    if not song_info:
        song_info = results[0]
    
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send("❌ Бот занят в другом канале!")
    
    duration_str = bot.format_duration(song_info.get('duration', 0))
    await ctx.send(f"🎲 **Рандом:** `{query}` | `{duration_str}`")
    await bot.add_to_queue(ctx, song_info)

@bot.command()
async def addrandom(ctx, count: int = 5):
    """!addrandom [число] - добавить N случайных треков (по умолчанию 5)"""
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send("❌ Бот занят в другом канале!")
    
    if count > 10:
        count = 10  # Лимит на случайное добавление
    
    msg = await ctx.send(f"🎲 Добавляю {count} случайных треков...")
    added = await bot.add_random_tracks(ctx, count=count)
    await msg.edit(content=f"✅ Добавлено {added} треков в очередь!")

@bot.command()
async def loop(ctx, mode: str = None):
    if mode not in ['off', 'one', 'all', None]:
        return await ctx.send("❌ Используй: `off`, `one` (текущий), `all` (очередь)")
    
    if mode is None:
        current = bot.loop_modes.get(ctx.guild.id, 'off')
        await ctx.send(f"🔁 Текущий режим: `{current}`")
        return
    
    bot.loop_modes[ctx.guild.id] = mode
    emojis = {'off': '❌', 'one': '🔂', 'all': '🔁'}
    await ctx.send(f"{emojis[mode]} Режим повтора: `{mode}`")

@bot.command()
async def remove(ctx, index: int):
    queue = bot.get_queue(ctx.guild.id)
    
    if not queue:
        return await ctx.send("📭 Очередь пуста")
    
    if index < 1 or index > len(queue):
        return await ctx.send(f"❌ Укажи номер от 1 до {len(queue)}")
    
    removed = queue.pop(index - 1)
    embed = discord.Embed(
        title="🗑️ Удалено из очереди",
        description=f"[{removed['title'][:50]}...]({removed['webpage_url']})",
        color=discord.Color.red()
    )
    await ctx.send(embed=embed)

@bot.command()
async def shuffle(ctx):
    queue = bot.get_queue(ctx.guild.id)
    if len(queue) < 2:
        return await ctx.send("❌ Недостаточно треков")
    
    rand.shuffle(queue)
    await ctx.send(f"🔀 Очередь перемешана! ({len(queue)} треков)")

@bot.command()
async def queue(ctx):
    queue_list = bot.get_queue(ctx.guild.id)
    current = bot.current.get(ctx.guild.id)
    
    if not current and not queue_list:
        return await ctx.send("📭 Очередь пуста")
    
    embed = discord.Embed(title="📜 Плейлист", color=discord.Color.purple())
    
    if current:
        start_time = bot.start_times.get(ctx.guild.id, time.time())
        elapsed = int(time.time() - start_time)
        total = current.get('duration_seconds', 0)
        
        progress_bar = bot.create_progress_bar(elapsed, total)
        time_str = bot.format_duration(elapsed)
        total_str = current['duration']
        
        embed.add_field(
            name="▶️ Сейчас играет",
            value=f"[{current['title']}]({current['webpage_url']})\n"
                  f"`{progress_bar}`\n"
                  f"`{time_str} / {total_str}`",
            inline=False
        )
        
        loop_mode = bot.loop_modes.get(ctx.guild.id, 'off')
        if loop_mode != 'off':
            embed.add_field(name="🔁 Режим", value=loop_mode, inline=True)
    
    if queue_list:
        text = ""
        for i, song in enumerate(queue_list[:10], 1):
            text += f"`{i}.` [{song['title'][:35]}...]({song['webpage_url']}) | `{song['duration']}`\n"
        if len(queue_list) > 10:
            text += f"\n*...и еще {len(queue_list)-10}*"
        embed.add_field(name=f"В очереди ({len(queue_list)}):", value=text, inline=False)
    
    history_count = len(bot.history.get(ctx.guild.id, []))
    embed.set_footer(text=f"⏮️ История: {history_count} треков")
    
    await ctx.send(embed=embed)

@bot.command()
async def skip(ctx):
    if ctx.voice_client and (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
        ctx.voice_client.stop()
        await ctx.send("⏭️ Пропущено")
    else:
        await ctx.send("❌ Ничего не играет")

@bot.command()
async def stop(ctx):
    if ctx.voice_client:
        bot.queues[ctx.guild.id] = []
        bot.current[ctx.guild.id] = None
        bot.history[ctx.guild.id] = []
        bot.start_times[ctx.guild.id] = None
        ctx.voice_client.stop()
        await ctx.voice_client.disconnect()
        await ctx.send("⏹️ Остановлено. Пока!")
    else:
        await ctx.send("❌ Я не в канале")

@bot.command()
async def leave(ctx):
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send("👋 Отключаюсь")
    else:
        await ctx.send("❌ Я не в канале")

@bot.command()
async def pause(ctx):
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.pause()
        await ctx.send("⏸️ Пауза")
    else:
        await ctx.send("❌ Ничего не играет")

@bot.command()
async def resume(ctx):
    if ctx.voice_client and ctx.voice_client.is_paused():
        ctx.voice_client.resume()
        await ctx.send("▶️ Продолжаю")
    else:
        await ctx.send("❌ Нет паузы")

@bot.command()
async def help(ctx):
    embed = discord.Embed(
        title="🎵 Sickwell Music Bot",
        description="Музыкальный бот с панелью управления",
        color=discord.Color.blue()
    )
    
    embed.add_field(
        name="🎛️ Основное",
        value="`!start` — Подключиться к каналу и открыть панель\n"
              "`!play <запрос>` — Включить трек\n"
              "`!addrandom [N]` — Добавить N случайных треков\n"
              "`!search <запрос>` — Выбрать из 5 вариантов\n"
              "`!random` — Один случайный трек (умный выбор)",
        inline=False
    )
    
    embed.add_field(
        name="📜 Очередь",
        value="`!queue` — Показать очередь\n"
              "`!remove <номер>` — Удалить трек\n"
              "`!shuffle` — Перемешать\n"
              "`!skip` — Пропустить\n"
              "`!previous` — Предыдущий трек",
        inline=False
    )
    
    embed.add_field(
        name="⌨️ Кнопки управления",
        value="`⏮️` Предыдущий | `⏸️` Пауза | `▶️` Продолжить | `⏭️` Следующий\n"
              "`🗑️` Удалить текущий | `📜` Очередь | `🔁` Повтор | `🔀` Перемешать\n"
              "`🎲` Добавить несколько случайных треков (3-8 шт) | `🚪` Отключить бота",
        inline=False
    )
    
    embed.set_footer(text="Умный рандом: не повторяет последние 20 жанров/артистов")
    await ctx.send(embed=embed)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❌ Укажи аргумент! Например: `!play` или `!remove 2`")
    else:
        print(f"Ошибка: {error}")

if __name__ == "__main__":
    TOKEN = os.getenv('DISCORD_TOKEN')
    if not TOKEN:
        print("❌ Создай файл .env с DISCORD_TOKEN=твой_токен")
        input("Нажми Enter...")
    else:
        bot.run(TOKEN)