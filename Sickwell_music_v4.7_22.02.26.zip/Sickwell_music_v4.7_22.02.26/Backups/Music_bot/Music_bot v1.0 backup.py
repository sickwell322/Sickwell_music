import discord
from discord.ext import commands
import yt_dlp as youtube_dl
import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

# Настройки FFmpeg (должен быть установлен в системе)
FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

# Настройки yt-dlp
YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }],
    'noplaylist': True,
    'quiet': True,
}

class MusicBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True  # Обязательно включи в настройках бота!
        intents.voice_states = True
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None ,
	    case_insensitive=True
        )
        
        self.queues = {}  # Очереди для серверов
        self.current = {}  # Текущий трек

    def get_queue(self, guild_id):
        if guild_id not in self.queues:
            self.queues[guild_id] = []
        return self.queues[guild_id]

    async def play_next(self, ctx):
        """Воспроизведение следующего трека"""
        queue = self.get_queue(ctx.guild.id)
        
        if queue:
            song = queue.pop(0)
            self.current[ctx.guild.id] = song
            
            if not ctx.voice_client:
                return
            
            source = discord.FFmpegPCMAudio(song['url'], **FFMPEG_OPTIONS)
            
            def after_playing(error):
                if error:
                    print(f"Ошибка: {error}")
                asyncio.run_coroutine_threadsafe(self.play_next(ctx), self.loop)
            
            ctx.voice_client.play(source, after=after_playing)
            
            # Отправляем embed с превью видео (это максимум "демки")
            embed = discord.Embed(
                title="▶️ Сейчас играет",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.green()
            )
            if song.get('thumbnail'):
                embed.set_image(url=song['thumbnail'])
            embed.set_footer(text=f"Длительность: {song.get('duration', 'N/A')} | Запросил: {song['requester']}")
            
            await ctx.send(embed=embed)
        else:
            self.current[ctx.guild.id] = None
            await ctx.send("✅ Очередь закончилась. Я отключаюсь...")
            if ctx.voice_client:
                await ctx.voice_client.disconnect()

    async def search_youtube(self, query):
        """Поиск на YouTube"""
        with youtube_dl.YoutubeDL(YDL_OPTIONS) as ydl:
            try:
                # Если это ссылка
                if 'youtube.com' in query or 'youtu.be' in query:
                    info = ydl.extract_info(query, download=False)
                else:
                    # Поиск по названию
                    info = ydl.extract_info(f"ytsearch:{query}", download=False)['entries'][0]
                
                return {
                    'title': info['title'],
                    'url': info['url'],
                    'webpage_url': info['webpage_url'],
                    'thumbnail': info.get('thumbnail'),
                    'duration': f"{info.get('duration', 0)//60}:{info.get('duration', 0)%60:02d}",
                }
            except Exception as e:
                print(f"Ошибка: {e}")
                return None

bot = MusicBot()

@bot.event
async def on_ready():
    print(f'✅ Бот {bot.user} запущен!')
    print('Команды: !play, !pause, !resume, !skip, !queue, !stop, !leave')

@bot.command()
async def play(ctx, *, query):
    """!play <название или ссылка YouTube>"""
    
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал сначала!")
    
    # Подключаемся к каналу
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send("❌ Бот занят в другом канале!")
    
    # Ищем трек
    async with ctx.typing():
        song = await bot.search_youtube(query)
    
    if not song:
        return await ctx.send("❌ Не удалось найти видео!")
    
    song['requester'] = ctx.author.name
    queue = bot.get_queue(ctx.guild.id)
    
    if ctx.voice_client.is_playing():
        queue.append(song)
        embed = discord.Embed(
            title="📝 Добавлено в очередь",
            description=f"[{song['title']}]({song['webpage_url']})",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=song['thumbnail'])
        embed.set_footer(text=f"Позиция: {len(queue)}")
        await ctx.send(embed=embed)
    else:
        queue.append(song)
        await bot.play_next(ctx)

@bot.command()
async def pause(ctx):
    """⏸️ Пауза"""
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.pause()
        await ctx.send("⏸️ Пауза")
    else:
        await ctx.send("❌ Ничего не играет")

@bot.command()
async def resume(ctx):
    """▶️ Продолжить"""
    if ctx.voice_client and ctx.voice_client.is_paused():
        ctx.voice_client.resume()
        await ctx.send("▶️ Продолжаю")
    else:
        await ctx.send("❌ Нет паузы")

@bot.command()
async def skip(ctx):
    """⏭️ Пропустить"""
    if ctx.voice_client and (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
        ctx.voice_client.stop()
        await ctx.send("⏭️ Пропущено")
    else:
        await ctx.send("❌ Нечего пропускать")

@bot.command()
async def queue(ctx):
    """📜 Очередь"""
    queue_list = bot.get_queue(ctx.guild.id)
    current = bot.current.get(ctx.guild.id)
    
    if not current and not queue_list:
        return await ctx.send("📭 Пусто")
    
    embed = discord.Embed(title="📜 Плейлист", color=discord.Color.purple())
    
    if current:
        embed.add_field(
            name="Сейчас:",
            value=f"[{current['title']}]({current['webpage_url']})",
            inline=False
        )
    
    if queue_list:
        text = ""
        for i, song in enumerate(queue_list[:10], 1):
            text += f"`{i}.` [{song['title'][:50]}]({song['webpage_url']})\n"
        if len(queue_list) > 10:
            text += f"\n*...и еще {len(queue_list)-10}*"
        embed.add_field(name="Далее:", value=text, inline=False)
    
    await ctx.send(embed=embed)

@bot.command()
async def stop(ctx):
    """⏹️ Стоп и выход"""
    if ctx.voice_client:
        bot.queues[ctx.guild.id] = []
        bot.current[ctx.guild.id] = None
        ctx.voice_client.stop()
        await ctx.voice_client.disconnect()
        await ctx.send("⏹️ Остановлено")
    else:
        await ctx.send("❌ Я не в канале")

@bot.command()
async def leave(ctx):
    """👋 Выйти"""
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send("👋 Пока!")
    else:
        await ctx.send("❌ Я не в канале")

@bot.command()
async def help(ctx):
    """❓ Помощь"""
    embed = discord.Embed(title="🎵 Команды", color=discord.Color.orange())
    embed.add_field(
        name="Управление",
        value="`!play <запрос>` — Найти и включить\n"
              "`!pause` — Пауза\n"
              "`!resume` — Продолжить\n"
              "`!skip` — Пропустить\n"
              "`!queue` — Очередь\n"
              "`!stop` — Остановить всё\n"
              "`!leave` — Выйти",
        inline=False
    )
    await ctx.send(embed=embed)

# Запуск
if __name__ == "__main__":
    TOKEN = os.getenv('DISCORD_TOKEN')
    if not TOKEN:
        print("❌ Создай файл .env и добавь: DISCORD_TOKEN=твой_токен")
    else:
        bot.run(TOKEN)