import discord
from discord.ext import commands
import yt_dlp as youtube_dl
import asyncio
import os
import random as rand
from dotenv import load_dotenv

load_dotenv()

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'postprocessors': [{
        'key': 'FFmpegExtractAudio',
        'preferredcodec': 'mp3',
        'preferredquality': '192',
    }],
    'noplaylist': True,
    'quiet': True,
    'no_warnings': True,
    'socket_timeout': 10,  # Таймаут соединения
    'retries': 2,  # Повторы при ошибке
}

RANDOM_QUERIES = [
    "phonk", "drift phonk", "slowed phonk", "brazilian phonk", "aggresive phonk",
    "funk brasil", "phonk remix", "phonk 2024", "drift music",
    "russian hits 2024", "russian rap", "russian pop", "русская музыка",
    "russian rock", "russian indie", "russian phonk", "kyivstoner",
    "korzh", "skriptonit", "morgenshtern", "big baby tape", "oxxxymiron",
    "face", "thomas mraz", "jedi mind tricks", "kizaru", "saluki",
    "aphrodite", "xcho", "andy panda", "miyagi", "timati", "egor krid",
    "slava marlow", "boulevard depo", "pharaoh", "lsp", "markul",
    "t-fest", "skryptonite", "niman", "zomb", "dequine",
    "sigma music", "gigachad music", "sad music", "night drive music",
    "gaming music 2024", "csgo music", "dota 2 music", "minecraft music",
    "lofi hip hop", "popular music 2024", "rock classics", "electronic dance music",
    "jazz relax", "indie pop", "classical music", "rap hits", "synthwave",
    "metal hits", "pop hits 2024", "nightcore", "acoustic covers",
    "the weeknd", "imagine dragons", "linkin park", "queen", "arctic monkeys",
    "radiohead", "nirvana", "metallica", "eminem", "kanye west", "drake",
    "dua lipa", "billie eilish", "post malone", "travis scott", "xxx tentacion"
]

class MusicBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.voice_states = True
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None,
            case_insensitive=True
        )
        
        self.queues = {}
        self.current = {}
        self.MAX_DURATION_SECONDS = 420  # 7 минут

    def get_queue(self, guild_id):
        if guild_id not in self.queues:
            self.queues[guild_id] = []
        return self.queues[guild_id]

    async def search_youtube(self, query, max_results=1):
        """Асинхронный поиск на YouTube (не блокирует бота)"""
        def search():
            with youtube_dl.YoutubeDL(YDL_OPTIONS) as ydl:
                try:
                    if 'youtube.com' in query or 'youtu.be' in query:
                        info = ydl.extract_info(query, download=False)
                        return [info] if max_results == 1 else info
                    else:
                        info = ydl.extract_info(f"ytsearch{max_results}:{query}", download=False)
                        return info['entries']
                except Exception as e:
                    error_msg = str(e)
                    if "age-restricted" in error_msg:
                        return "age_restricted"
                    print(f"Ошибка поиска: {e}")
                    return None
        
        # Запускаем в отдельном потоке с таймаутом
        try:
            loop = asyncio.get_event_loop()
            results = await asyncio.wait_for(
                loop.run_in_executor(None, search),
                timeout=15.0  # Максимум 15 секунд на поиск
            )
            return results
        except asyncio.TimeoutError:
            print("Поиск превысил 15 секунд")
            return None
        except Exception as e:
            print(f"Ошибка: {e}")
            return None

    async def play_next(self, ctx):
        queue = self.get_queue(ctx.guild.id)
        
        if queue:
            song = queue.pop(0)
            self.current[ctx.guild.id] = song
            
            if not ctx.voice_client:
                return
            
            source = discord.FFmpegPCMAudio(song['url'], **FFMPEG_OPTIONS)
            
            def after_playing(error):
                if error:
                    print(f"Ошибка: {error}")
                asyncio.run_coroutine_threadsafe(self.play_next(ctx), self.loop)
            
            ctx.voice_client.play(source, after=after_playing)
            
            embed = discord.Embed(
                title="▶️ Сейчас играет",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.green()
            )
            if song.get('thumbnail'):
                embed.set_thumbnail(url=song['thumbnail'])
            embed.set_footer(text=f"Длительность: {song.get('duration', 'N/A')} | Запросил: {song['requester']}")
            await ctx.send(embed=embed)
        else:
            self.current[ctx.guild.id] = None
            await ctx.send("✅ Очередь закончилась. Отключаюсь...")
            if ctx.voice_client:
                await ctx.voice_client.disconnect()

    async def add_to_queue(self, ctx, song_info):
        song = {
            'title': song_info['title'],
            'url': song_info['url'],
            'webpage_url': song_info['webpage_url'],
            'thumbnail': song_info.get('thumbnail'),
            'duration': f"{song_info.get('duration', 0)//60}:{song_info.get('duration', 0)%60:02d}" if isinstance(song_info.get('duration'), int) else "N/A",
            'duration_seconds': song_info.get('duration', 0) if isinstance(song_info.get('duration'), int) else 0,
            'requester': ctx.author.name
        }
        
        if ctx.voice_client.is_playing():
            self.get_queue(ctx.guild.id).append(song)
            embed = discord.Embed(
                title="📝 Добавлено в очередь",
                description=f"[{song['title']}]({song['webpage_url']})",
                color=discord.Color.blue()
            )
            embed.set_thumbnail(url=song['thumbnail'])
            await ctx.send(embed=embed)
        else:
            self.get_queue(ctx.guild.id).append(song)
            await self.play_next(ctx)

bot = MusicBot()

@bot.event
async def on_ready():
    print(f'✅ Бот {bot.user} запущен!')
    print('Введи !help в Discord для списка команд')

@bot.command()
async def play(ctx, *, query):
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send("❌ Бот занят в другом канале!")
    
    async with ctx.typing():
        results = await bot.search_youtube(query, max_results=1)
    
    if results == "age_restricted":
        return await ctx.send("🔞 Видео имеет возрастное ограничение. Попробуй другое.")
    
    if not results or len(results) == 0:
        return await ctx.send("❌ Не удалось найти видео!")
    
    song_info = results[0] if isinstance(results, list) else results
    await bot.add_to_queue(ctx, song_info)

@bot.command()
async def search(ctx, *, query):
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    async with ctx.typing():
        results = await bot.search_youtube(query, max_results=5)
    
    if results == "age_restricted":
        return await ctx.send("🔞 Найдены только видео с возрастным ограничением. Попробуй другой запрос.")
    
    if not results or len(results) == 0:
        return await ctx.send("❌ Ничего не найдено!")
    
    embed = discord.Embed(
        title=f"🔍 Результаты поиска: {query}",
        description="Напиши номер трека (1-5) для выбора\nили `отмена` для отмены",
        color=discord.Color.gold()
    )
    
    for i, video in enumerate(results[:5], 1):
        duration = f"{video.get('duration', 0)//60}:{video.get('duration', 0)%60:02d}" if isinstance(video.get('duration'), int) else "N/A"
        embed.add_field(
            name=f"{i}. {video['title'][:50]}",
            value=f"Автор: {video.get('uploader', 'N/A')} | Длительность: {duration}",
            inline=False
        )
    
    await ctx.send(embed=embed)
    
    def check(m):
        return m.author == ctx.author and m.channel == ctx.channel and \
               (m.content.isdigit() and 1 <= int(m.content) <= 5 or m.content.lower() in ['отмена', 'cancel'])
    
    try:
        response = await bot.wait_for('message', check=check, timeout=30.0)
        
        if response.content.lower() in ['отмена', 'cancel']:
            return await ctx.send("❌ Отменено")
        
        choice = int(response.content) - 1
        selected = results[choice]
        
        if not ctx.voice_client:
            await ctx.author.voice.channel.connect()
        elif ctx.voice_client.channel != ctx.author.voice.channel:
            return await ctx.send("❌ Бот занят в другом канале!")
        
        await bot.add_to_queue(ctx, selected)
        
    except asyncio.TimeoutError:
        await ctx.send("⏰ Время вышло!")
    except Exception as e:
        await ctx.send(f"❌ Ошибка: {e}")

@bot.command()
async def random(ctx):
    if not ctx.author.voice:
        return await ctx.send("❌ Зайди в голосовой канал!")
    
    query = rand.choice(RANDOM_QUERIES)
    
    async with ctx.typing():
        results = await bot.search_youtube(query, max_results=10)
    
    if results == "age_restricted":
        return await ctx.send("🔞 Не удалось найти подходящий трек (возрастное ограничение). Попробуй еще раз.")
    
    if not results:
        return await ctx.send("❌ Не удалось найти музыку!")
    
    # Ищем трек не длиннее 7 минут
    song_info = None
    attempts = 0
    
    while attempts < min(5, len(results)):
        candidate = results[attempts]
        duration = candidate.get('duration', 0)
        
        if isinstance(duration, int) and 0 < duration <= bot.MAX_DURATION_SECONDS:
            song_info = candidate
            break
        attempts += 1
    
    # Если не нашли короткий, берем первый
    if not song_info:
        song_info = results[0]
    
    if not ctx.voice_client:
        await ctx.author.voice.channel.connect()
    elif ctx.voice_client.channel != ctx.author.voice.channel:
        return await ctx.send("❌ Бот занят в другом канале!")
    
    duration_str = f"{song_info.get('duration', 0)//60}:{song_info.get('duration', 0)%60:02d}" if isinstance(song_info.get('duration'), int) else "N/A"
    await ctx.send(f"🎲 **Рандом:** `{query}` | Длительность: `{duration_str}`")
    await bot.add_to_queue(ctx, song_info)

@bot.command()
async def shuffle(ctx):
    queue = bot.get_queue(ctx.guild.id)
    
    if len(queue) < 2:
        return await ctx.send("❌ Недостаточно треков (нужно минимум 2)")
    
    rand.shuffle(queue)
    await ctx.send(f"🔀 Очередь перемешана! Треков: {len(queue)}")

@bot.command()
async def pause(ctx):
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.pause()
        await ctx.send("⏸️ Пауза")
    else:
        await ctx.send("❌ Ничего не играет")

@bot.command()
async def resume(ctx):
    if ctx.voice_client and ctx.voice_client.is_paused():
        ctx.voice_client.resume()
        await ctx.send("▶️ Продолжаю")
    else:
        await ctx.send("❌ Нет паузы")

@bot.command()
async def skip(ctx):
    if ctx.voice_client and (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
        ctx.voice_client.stop()
        await ctx.send("⏭️ Пропущено")
    else:
        await ctx.send("❌ Нечего пропускать")

@bot.command()
async def queue(ctx):
    queue_list = bot.get_queue(ctx.guild.id)
    current = bot.current.get(ctx.guild.id)
    
    if not current and not queue_list:
        return await ctx.send("📭 Очередь пуста")
    
    embed = discord.Embed(title="📜 Плейлист", color=discord.Color.purple())
    
    if current:
        embed.add_field(
            name="Сейчас играет:",
            value=f"[{current['title']}]({current['webpage_url']})",
            inline=False
        )
    
    if queue_list:
        text = ""
        for i, song in enumerate(queue_list[:15], 1):
            text += f"`{i}.` [{song['title'][:40]}...]({song['webpage_url']})\n"
        if len(queue_list) > 15:
            text += f"\n*...и еще {len(queue_list)-15}*"
        embed.add_field(name=f"В очереди ({len(queue_list)}):", value=text, inline=False)
    
    await ctx.send(embed=embed)

@bot.command()
async def stop(ctx):
    if ctx.voice_client:
        bot.queues[ctx.guild.id] = []
        bot.current[ctx.guild.id] = None
        ctx.voice_client.stop()
        await ctx.voice_client.disconnect()
        await ctx.send("⏹️ Остановлено. Пока!")
    else:
        await ctx.send("❌ Я не в канале")

@bot.command()
async def leave(ctx):
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send("👋 Отключаюсь")
    else:
        await ctx.send("❌ Я не в канале")

@bot.command()
async def help(ctx):
    embed = discord.Embed(
        title="🎵 Sickwell Music Bot",
        description="Музыкальный бот для Discord с поддержкой YouTube\n🎲 Рандомные треки не длиннее 7 минут!",
        color=discord.Color.blue()
    )
    
    embed.add_field(
        name="🎶 Воспроизведение",
        value=
        "`!play <название/ссылка>` — Быстрый поиск и play\n"
        "`!search <название>` — Выбрать 1 из 5 вариантов\n"
        "`!random` — Случайный трек (фонк/русская/блогеры/поп)",
        inline=False
    )
    
    embed.add_field(
        name="⏯️ Управление",
        value=
        "`!pause` — Пауза\n"
        "`!resume` — Продолжить\n"
        "`!skip` — Пропустить\n"
        "`!stop` — Остановить",
        inline=False
    )
    
    embed.add_field(
        name="📜 Очередь",
        value=
        "`!queue` — Показать очередь\n"
        "`!shuffle` — Перемешать 🔀\n"
        "`!leave` — Выйти из канала",
        inline=False
    )
    
    embed.add_field(
        name="💡 Подсказки",
        value=
        "• Регистр не важен: `!play` = `!PLAY`\n"
        "• В `!search` пиши цифру 1-5 или `отмена`\n"
        "• `!random` включает: Phonk, Русская музыка, Блогеры, Поп",
        inline=False
    )
    
    embed.set_footer(text=f"Запросил: {ctx.author.name} | Бот готов к работе!")
    await ctx.send(embed=embed)

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        return
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❌ Укажи аргумент! Например: `!play never give you up`")
    else:
        print(f"Ошибка: {error}")

if __name__ == "__main__":
    TOKEN = os.getenv('DISCORD_TOKEN')
    if not TOKEN:
        print("=" * 50)
        print("❌ ОШИБКА: Не найден токен!")
        print("Создай файл .env в папке с ботом:")
        print("DISCORD_TOKEN=твой_токен_здесь")
        print("=" * 50)
        input("Нажми Enter чтобы закрыть...")
    else:
        try:
            bot.run(TOKEN)
        except Exception as e:
            print(f"❌ Ошибка запуска: {e}")
            input("Нажми Enter чтобы закрыть...")